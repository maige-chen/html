const e=Object.freeze({CARWASH:{title:"洗车App",home:"cw.html"}});export{e as S};
